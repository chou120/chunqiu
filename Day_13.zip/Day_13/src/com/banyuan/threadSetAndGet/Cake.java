package com.banyuan.threadSetAndGet;

public class Cake {

    String   name;
    String   type;

}
