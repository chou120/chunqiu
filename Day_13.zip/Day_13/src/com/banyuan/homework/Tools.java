package com.banyuan.homework;

public class Tools {

    int  number=1;
    int  n=1;


}
