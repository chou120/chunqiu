package com.banyuan.com;

public class Student {

    String   name;
    int  age;

    boolean  flag;  //唤醒线程的一个标记


}
