package com.banyuan.MyThreadHomework;

import sun.lwawt.macosx.CSystemTray;

public class Homework {

    int   count=1;
    int number=1;




}

