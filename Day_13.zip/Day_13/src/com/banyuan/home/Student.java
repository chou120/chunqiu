package com.banyuan.home;

public class Student {

    String   name;
    int  age;

   // boolean  flag;  //唤醒线程的一个标记
    String    str="";

}
