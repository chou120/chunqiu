package com.banyuan.thread6;


//消费者
public class GetValueThread implements   Runnable {
    @Override
    public void run() {

    }
}
