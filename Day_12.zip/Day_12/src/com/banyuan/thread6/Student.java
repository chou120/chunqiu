package com.banyuan.thread6;

public class Student {

    String name;
    int   age;

    //没有人的其他成员

}
