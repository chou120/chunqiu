package com.banyuan.thread6;


//生产者
public class SetValueThread   implements   Runnable {


    @Override
    public void run() {

    }
}
