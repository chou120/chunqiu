package com.banyuan.thread5;

public class Student {
}
