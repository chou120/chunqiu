package com.banyuan.thread5;

import java.util.*;

public class Test2 {

    public static void main(String[] args) {
//        StringBuffer
//        Vector
//        Stack
       // new Hashtable();

       List list= Collections.synchronizedList(new ArrayList<>());


    }

}
