package com.banyuan.threadDemo6;

public class Tools {

    static  Object  o1=new Object();
    static  Object   o2=new Object();

}
