create view ma_st as
select `m`.`majorname` AS `majorname`, `s`.`studentname` AS `studentname`
from (`jian`.`major` `m`
         left join `jian`.`student` `s` on ((`m`.`majorid` = `s`.`majorid`)));

