create
    definer = root@localhost procedure into_stu(IN sno varchar(20))
BEGIN
	select s.* from  student s where s.studentno=sno;
end;

